# Teluala brand kit

The official Teluala logos, symbols, and icons for use in projects,
documentation, and applications.

## Recommended files

- `svg/logo-horizontal-black.svg`: primary logo on light backgrounds
- `svg/logo-horizontal-white.svg`: primary logo on dark backgrounds
- `svg/mark-black.svg` and `svg/mark-white.svg`: mark-only uses
- `svg/icon-square-light.svg` and `svg/icon-square-dark.svg`: app/profile icons
- `web/`: favicon, Apple touch icon, Android/PWA icons, and web manifest
- `svg/banner-wide-*.svg`: 1600 × 500 wide banners
- `svg/social-preview-*.svg`: 1200 × 630 social preview cards

## Usage

- Prefer the horizontal logo at 160 px wide or larger.
- Use the mark below 160 px, and `web/favicon.svg` for very small UI contexts.
- Keep at least 5% of the mark width as clear space.
- Preserve the aspect ratio. Do not rotate, redraw, add effects, or change the
  relationship between the globe, wings, and wordmark.
- Primary monochrome colors are black `#000000` and white `#FFFFFF`.
- The supplied neutral dark background is `#0B0F14`.

The SVG files contain paths only; they do not embed raster images or require fonts.

## Permissions

See BRAND.md for permissions to use the artwork. The software MIT license
does not apply to the brand artwork.
